<?php
echo "<html> <body> <h1>hello world</h1><body></html>";
?>